  
  //  ([A - Z] +)
    const expresiones = {
        cedula:/^[0-9]{9,12}$/, //numeros del 0 al 9 , minimo 9 digitos , maximo 12 digitos
        usuario:/^[\w\-\.]{4,16}$/, // Letras, numeros, guion y guion_bajo
        nombre:/^[a-zA-ZÀ-ÿ\s]{1,40}$/, // Letras y espacios, pueden llevar acentos.
        password:/^\w{6,12}$/, // 6 a 12 digitos.
        mayusculaObligada:/[A-Z]+/, // Una letra mayuscula obligada.
        numeroObligada:/[0-9]+/, // Un numero obligada.
        especial_obligado:/[\_\$\.\!\@@\%\#\&\(\)\=\·\-\*\;\:\,\?\¿\'\{\}\#]+/, //un numero caracter especial obligado que tenga
        correo:/^[A-Za-z0-9]+[@@]{1}[a-z]+\.[a-z]{2,3}$/,
        fecha:/^\d{2}\/\d{2}\/\d{4}$/,  //formato fecha 21/02/2021
        codigo_postal:/^\d{5}$/,
        telefono:/^\d{8,14}$/ // 8 a 14 numeros.
    }; 

    //campos opcionales son aquellos que permiten valores null , entonces solamente se le agrega la clase bootsrap de valido
    const validar_campo_opcional = (campo) => {
            campo.classList.add('is-valid');          
    }

    //valida campo numerico si es mayor o igual a 0 campo valido , si es negativo el campo es invalido
    const validar_campo_numerico = (campo) => {
   
        if (campo.value >= 0) {
            campo.classList.add('is-valid');
            campo.classList.remove('is-invalid');      
         } else {
             campo.classList.remove('is-valid'); 
             campo.classList.add('is-invalid');
         }
    }


    //validar campos recive como parametros la expresion que se va usar, el campo que se analizara,
    //
    const validar_campo = (expresion, campo) => {

        if (expresion.test(campo.value)) {
           campo.classList.add('is-valid');
           campo.classList.remove('is-invalid');      
        } else {
            campo.classList.remove('is-valid'); 
            campo.classList.add('is-invalid');
        }
    }


    //valida el formulario login depndiendo el objeto que lanzo la llamada a la funcion
    const validar_login = (e) => {

        switch (e.target.name) {
            case "txt_nombre":
                validar_campo(expresiones.nombre, e.target);
                break;
            case "txt_cantidad":
               validar_campo_numerico(e.target);
                break;
            case "txt_direccion":
                 validar_campo_opcional(e.target)
                 break;

        }
    }

    // todos los input de formulario frm_login
  const frm_inputs = document.querySelectorAll('#frm_departamento input');

    //se le agrega el escuchador del evento keyup a todos los elementos del input
    //se le agrega escuchador blur que es cuando da un click afuera
    //cuando se accede a funciones en javascript tienen que estar declaradas arriba antes de usarlas
    frm_inputs.forEach((i) => {
       // i.addEventListener('keyup',validar_login);
        i.addEventListener('blur',validar_login);
    });
