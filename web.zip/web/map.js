
function Localizacion(posicion) {
  var latitude = posicion.coords.latitude;
  var longitude = posicion.coords.longitude;
}
google.maps.event.addDomListener(window,"load",function(){

// const ubicacion = new Localizacion(()=>{

  // const myLatLng = {lat: ubicacion.latitude, lng:ubicacion.longitude};
  const myLatLng = {lat:10.0000000 , lng:-84.0000000};

  const options = {
    center: myLatLng,
  zoom: 14}

  var map = document.getElementById('map');
  const mapa = new google.maps.Map(map,options);


  const marcador = new google.maps.Marker({
    position: myLatLng,
    map:mapa
  });

  var informacion = new google.maps.InfoWindow();

marcador.addListener('click',function() {
  informacion.open(mapa,marcador);
});


var autocomplete = document.getElementById('txt_autocomplete');
const buscador = new google.maps.places.Autocomplete(autocomplete)
buscador.bindTo("bounds",mapa);


 buscador.addListener('place_changed',function(){
informacion.close();
marcador.setVisible(false);
var place = buscador.getPlace();

if(!place.geometry.viewport){
window.alert('Error al mostrar lugar');
return;
}

if(place.geometry.viewport){
mapa.fitBounds(place.geometry.viewport);
}else{
  mapa.setCenter(place.geometry.location);
  mapa.setZoom(18);
}

marcador.setPosition(place.geometry.location);
marcador.setVisible(true);


var address = "";

if(place.address_components){

address = [
  (place.address_components[0] && place.address_components[0].short_name || ''),
  (place.address_components[1] && place.address_components[1].short_name || ''),
  (place.address_components[2] && place.address_components[2].short_name || ''),
];
} 
informacion.setContent('<div><strong>'+place.name+'</strong><br>'+address+'</div>')


// });
   

});

});





// function initAutocomplete() {
//     const map = new google.maps.Map(document.getElementById("map"), {
//       center: { lat: 9.9356284, lng: -84.1483648},
//       zoom: 10,
//       mapTypeId: "roadmap"
//     });
//     // Create the search box and link it to the UI element.
//     const input = document.getElementById("pac-input");
//     const searchBox = new google.maps.places.SearchBox(input);
//     map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);
//     // Bias the SearchBox results towards current map's viewport.
//     map.addListener("bounds_changed", () => {
//       searchBox.setBounds(map.getBounds());
//     });
//     let markers = [];
//     // Listen for the event fired when the user selects a prediction and retrieve
//     // more details for that place.
//     searchBox.addListener("places_changed", () => {
//       const places = searchBox.getPlaces();
  
//       if (places.length == 0) {
//         return;
//       }
//       // Clear out the old markers.
//       markers.forEach((marker) => {
//         marker.setMap(null);
//       });
//       markers = [];
//       // For each place, get the icon, name and location.
//       const bounds = new google.maps.LatLngBounds();
//       places.forEach((place) => {
//         if (!place.geometry || !place.geometry.location) {
//           console.log("Returned place contains no geometry");
//           return;
//         }
//         const icon = {
//           url: place.icon,
//           size: new google.maps.Size(71, 71),
//           origin: new google.maps.Point(0, 0),
//           anchor: new google.maps.Point(17, 34),
//           scaledSize: new google.maps.Size(25, 25),
//         };
//         // Create a marker for each place.
//         markers.push(
//           new google.maps.Marker({
//             map,
//             icon,
//             title: place.name,
//             position: place.geometry.location,
//           })
//         );
  
//         if (place.geometry.viewport) {
//           // Only geocodes have viewport.
//           bounds.union(place.geometry.viewport);
//         } else {
//           bounds.extend(place.geometry.location);
//         }
//       });
//       map.fitBounds(bounds);
//     });
  // }
     