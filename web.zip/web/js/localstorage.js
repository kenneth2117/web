//la idea de tenre el objeto persona es poderlo usar en otros metodos
//sin la nesesidad de estar consultando el localstorage a cada rato
let persona = {
    usuario:null,
    tipo:null
};

//guarda en el localstorage el nombre y el tipo de acceso tiene que ser string
function guardar_LocaStorage(nombre,tipo){
    persona = {
        usuario:nombre,
        tipo:tipo     
    };
    localStorage.setItem("persona",JSON.stringify(persona));
};
/* le pasas el ID de la etiqueta que esta en el html y actualiza su valor(recuerde que son dos id etiquetas ) */
const actualizar_etiqueta = (id_etiqueta1,id_etiqueta2) => {
    let x = document.getElementById(id_etiqueta1);
    let y = document.getElementById(id_etiqueta2);
    x.innerHTML = persona.usuario;
    y.innerHTML = persona.tipo;
}

const obtener_LocalStorage = () => {
    if(localStorage.getItem('persona')){
        let per = JSON.parse(localStorage.getItem('persona'));
       persona.usuario = per.usuario;
       persona.tipo = per.tipo;  
       //llamo al metodo de actualizar etiqueta 
      actualizar_etiqueta('usu','tip')
       return true;
    }else{
        persona.usuario = null;
        persona.tipo = null;
        return false;
    }   
}


const btn_cargar = document.getElementById('btn_cargarUsuario').addEventListener('click',obtener_LocalStorage);
